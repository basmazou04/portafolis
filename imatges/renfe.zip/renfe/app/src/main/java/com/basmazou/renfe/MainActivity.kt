package com.basmazou.renfe

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.basmazou.renfe.databinding.ActivityMainBinding
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //per a que es generi el preu quan s'inicia l'aplicacio
        generarPreuViatge()

        //configurar el botó per calcular el descompte quan es faci clic
        binding.botoDescompte.setOnClickListener {
            calcularDescompte()
        }

    }

    //funció per generar un preu aleatòri entre 10 i 50, i posar-lo al textview
    private fun generarPreuViatge() {

        val preuAleatori = Random.nextInt(10, 51)
        binding.preuViatge.text = "El preu d'aquest viatge és de: $preuAleatori €"

    }

    //funcio per calcular el descompte que li pertoca a l'usuari
    private fun calcularDescompte() {

        //obtenim l'edat que ha introduit l'usuari
        val edatUsuari = binding.edatUsuari.text.toString()
        val dniUsuari = binding.dniUsuari.text.toString()

        //validar els camps, combropar que tenen dades
        if (edatUsuari.isEmpty()) {
            binding.preuDescomptat.text = "Si us plau, introdueix la teva edat"
            return
        }

        if (dniUsuari.isEmpty()) {
            binding.preuDescomptat.text = "Si us plau, introdueix el teu DNI"
            return
        }

        val edat = edatUsuari.toInt()

        // Validar que el DNI tingui exactament 9 caràcters
        if (dniUsuari.length != 9) {
            binding.preuDescomptat.text = "El DNI ha de tenir exactament 9 caràcters"
            return
        }

        // Validar rang d'edat (0-100)
        if (edat <= 0 || edat > 100) {
            binding.preuDescomptat.text = "Edat no vàlida"
            return
        }

        //obtenir el preu que ha generat l'aplicacio per al viatge
        val preuObtingut = binding.preuViatge.text.toString()
        val preuDelViatge = if (preuObtingut.contains("€")) {
            preuObtingut.substringAfter(": ").substringBefore(" €").toInt()
        } else {
            Random.nextInt(10, 50)
        }

        var descompte = 0
        var preuFinal = preuDelViatge

        //aplicar el descompte segons l'edat que ha introduit l'usuari
        when {
            edat < 18 || edat > 64 -> {
                descompte = 50
                preuFinal = preuDelViatge * 50 / 100
            }

            edat in 18..29 -> {
                descompte = 30
                preuFinal = preuDelViatge * 70 / 100
            }

            edat in 30..64 -> {
                descompte = 0
                preuFinal = preuDelViatge
            }

            else -> {
                //comprovar edats invàlides
                binding.preuDescomptat.text = "Edat no vàlida."
                return
            }
        }

        //mostrar el resultat per a l'usuari
        binding.preuDescomptat.text = "Tens un descompte del $descompte" + " %. " +
                                        "El preu final és de $preuFinal" + " €"
    }
}